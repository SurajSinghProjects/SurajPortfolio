// fixes header js
$(window).scroll(function() {
    if ($(window).scrollTop() >= 100) {
        $('header').addClass('fixed-header');
    } else {
        $('header').removeClass('fixed-header');
    }
});
// swiper slider
$(document).ready(function() {

    if ($('.brands_slider').length) {
        var brandsSlider = $('.brands_slider');

        brandsSlider.owlCarousel({
            loop: true,
            autoplay: true,
            autoplayTimeout: 2000,
            nav: false,
            dots: false,
            autoWidth: true,
            items: 8,
            margin: 42,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 1,
                        infinite: true,
                        dots: false
                    }
                },
                {
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1
                    }
                }
            ]
        });

        if ($('.brands_prev').length) {
            var prev = $('.brands_prev');
            prev.on('click', function() {
                brandsSlider.trigger('prev.owl.carousel');
            });
        }

        if ($('.brands_next').length) {
            var next = $('.brands_next');
            next.on('click', function() {
                brandsSlider.trigger('next.owl.carousel');
            });
        }
    }


});
// --------------------- password Toggle Start
var clicked = 0;

$(".toggle-password").click(function(e) {
    e.preventDefault();

    $(this).toggleClass("toggle-password");
    if (clicked == 0) {
        $(this).html('<img src="assets/images/eyes-open.svg" alt="Eye Close">');
        clicked = 1;
    } else {
        $(this).html('<img src="assets/images/eyes-close.svg" alt="Eye Close">');
        clicked = 0;
    }

    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
        input.attr("type", "text");
    } else {
        input.attr("type", "password");
    }
});

// ------------------end
// // // --------------------- mobile dropdown toggle
// var hide = 0;

// $(".custom-down-arrow ").click(function(e) {
//     e.preventDefault();

//     $(this).toggleClass("");
//     if (hide == 0) {
//         $(this).css({ "stroke": "red", "transform": "rotate(180deg)" });
//         hide = 1;
//     } else {
//         $(this).css({ "color": "black", "transform": "rotate(0deg)" });
//         hide = 0;
//     }

// });